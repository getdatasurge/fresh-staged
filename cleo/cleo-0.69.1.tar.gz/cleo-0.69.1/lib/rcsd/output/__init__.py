"""
RCSD Output - LLM-AGENT-FIRST compliant output formatting.

Submodules:
    - formatter: JSON output formatter with _meta envelope
"""

__all__ = [
    # Will be populated as output module is implemented
]
