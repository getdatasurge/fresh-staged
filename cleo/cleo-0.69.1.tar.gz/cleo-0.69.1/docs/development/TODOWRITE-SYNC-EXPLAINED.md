# How CLEO Syncs with Claude Code's TodoWrite

> A plain-English explanation of bidirectional task synchronization

---

## The Problem I was Solving

1. Claude Code has a built-in **TodoWrite tool** - an ephemeral todo list that only lives during your session. When your session ends, it's gone.

2. **Claude-todo** is a persistent bash CLI that stores tasks in JSON files that survive across sessions.

3. **The challenge**: How do we let Claude work with its native TodoWrite during a session, but preserve that work in our durable system?

---

## The Solution: Inject → Work → Extract

Think of it like a **check-out/check-in system** at a library:

```
┌─────────────────┐     ┌─────────────────┐     ┌─────────────────┐
│  SESSION START  │ ──► │  DURING SESSION │ ──► │   SESSION END   │
│                 │     │                 │     │                 │
│  "Check out"    │     │  Claude works   │     │  "Check in"     │
│  tasks to       │     │  with TodoWrite │     │  changes back   │
│  TodoWrite      │     │  naturally      │     │  to cleo │
└─────────────────┘     └─────────────────┘     └─────────────────┘
```

### Key Files

| File | Purpose |
|------|---------|
| `scripts/sync-todowrite.sh` | Main orchestrator & subcommand router |
| `scripts/inject-todowrite.sh` | Session start: cleo → TodoWrite |
| `scripts/extract-todowrite.sh` | Session end: TodoWrite → cleo |
| `lib/todowrite-integration.sh` | Grammar transformation & status mapping |
| `docs/specs/TODOWRITE-SYNC-SPEC.md` | Authoritative specification |

---

## Step 1: Inject (Session Start)

**Command**: `cleo sync --inject`

**What happens**:
1. Reads your tasks from cleo
2. Picks the most relevant ones (focused task + dependencies + high priority)
3. Converts them to TodoWrite's simpler format
4. **Embeds task IDs in the content** as `[T001]` prefixes

**Example output**:
```json
{
  "todos": [
    {
      "content": "[T001] [!] Implement authentication",
      "status": "in_progress",
      "activeForm": "Implementing authentication"
    },
    {
      "content": "[T002] [BLOCKED] Write auth tests",
      "status": "pending",
      "activeForm": "Writing auth tests"
    }
  ]
}
```

**The magic**: Those `[T001]` prefixes are how we track tasks across systems. TodoWrite doesn't know what they mean - it just treats them as part of the task title.

**Behind the scenes**: A session state file is saved that remembers which tasks were sent out:

```json
// .cleo/sync/todowrite-session.json
{
  "session_id": "session_20251215_143022_a1b2c3",
  "injected_at": "2025-12-15T14:30:22Z",
  "injectedPhase": "core",
  "injected_tasks": ["T001", "T002", "T003"],
  "task_metadata": {
    "T001": {"phase": "core", "priority": "high", "status": "pending"},
    "T002": {"phase": "core", "priority": "medium", "status": "blocked"}
  },
  "snapshot": { "todos": [...] }
}
```

This enables:
- **Diff detection**: Compare what was sent vs what came back
- **Phase inheritance**: New tasks inherit phase from focused task
- **Change warnings**: Detect if project phase changed during session

**Why embed IDs in content instead of using a separate mapping?**
> No schema coupling - survives TodoWrite version changes. The ID prefix is just text to TodoWrite.

---

## Step 2: Work (During Session)

Claude uses TodoWrite normally:
- Marks tasks `in_progress` when starting work
- Marks tasks `completed` when done
- Adds new tasks as needed (these won't have `[T###]` prefixes)

**No special behavior required** - Claude just works with its native tool.

---

## Step 3: Extract (Session End)

**Command**: `cleo sync --extract <todowrite-state.json>`

**What happens**:
1. Reads the final TodoWrite state
2. Parses those `[T001]` prefixes to identify tasks
3. Compares against what was originally injected
4. Detects four types of changes:

| Change Type | How We Know | What We Do |
|-------------|-------------|------------|
| **Completed** | `status: completed` | Mark done in cleo |
| **Progressed** | `status: in_progress` (was pending) | Update to active |
| **New tasks** | No `[T###]` prefix | Create in cleo |
| **Removed** | Was injected but now missing | Log it (don't delete) |

5. Cleans up the session state file

---

## The Key Insight: Content Prefix = ID Preservation

TodoWrite only has 3 fields: `content`, `status`, `activeForm`

Claude-todo has 10+ fields: `id`, `title`, `status`, `priority`, `phase`, `depends`, `labels`, `notes`, etc.

**We can't sync everything** - it's "lossy by design". But we CAN preserve:
- **Task identity** via `[T001]` prefix in content
- **Progress** via status field
- **Context** by creating new tasks discovered during work

Everything else (priority, labels, dependencies) stays safe in cleo.

---

## Status Mapping

The two systems have different status values (`lib/todowrite-integration.sh:177-189`):

| cleo | → TodoWrite | Notes |
|-------------|-------------|-------|
| `pending` | `pending` | Same |
| `active` | `in_progress` | Renamed |
| `blocked` | `pending` + `[BLOCKED]` marker | Downgraded (info in marker) |
| `done` | (not sent) | Already done = don't inject |

| TodoWrite | → cleo | Notes |
|-----------|---------------|-------|
| `pending` | `pending` | Same |
| `in_progress` | `active` | Renamed |
| `completed` | `done` | Via complete-task.sh |

---

## Task Selection: Not Everything Gets Injected

We don't dump all tasks into TodoWrite. There's a **tiered priority system** (`inject-todowrite.sh:273-294`):

1. **Tier 1**: The focused task (always included)
2. **Tier 2**: Tasks that depend on the focused task
3. **Tier 3**: High-priority tasks in the same phase
4. **Tier 4**: Everything else

**Maximum**: 8 tasks (configurable via `--max-tasks`)

**Why limit to 8?** Cognitive load limit + TodoWrite UI constraints. Keeps Claude focused on relevant work.

---

## New Task Phase Inheritance

When Claude creates a new task during a session (without a `[T###]` prefix), we need to decide what phase it belongs to (`extract-todowrite.sh:296-338`).

**Priority order**:
1. `--default-phase` flag (if specified)
2. The focused task's phase (most common)
3. The "most active" phase (phase with most pending tasks)
4. Project's current phase
5. Config default

This ensures new tasks fit naturally into your workflow.

---

## Conflict Resolution

**Simple rule**:
- **Claude-todo is authoritative for task existence** (we never delete tasks just because they're missing from TodoWrite)
- **TodoWrite is authoritative for session progress** (if it says "completed", it's done)

If there's a conflict, we warn but don't fail.

---

## Key Design Decisions

| Decision | Rationale |
|----------|-----------|
| Content prefix `[T###]` for ID | No schema coupling - survives TodoWrite version changes |
| Maximum 8 tasks | Cognitive load limit + TodoWrite UI constraints |
| Session state file | Simple file I/O; enables crash recovery; no dependencies |
| Warn-don't-fail conflicts | Robustness for real-world usage |
| `blocked` → `pending` downgrade | TodoWrite has no blocked status; marker preserves info |
| Auto-create new tasks (v1) | Lower friction; user confirmation planned for v2 |

---

## One-Way Export vs Bidirectional Sync

| Command | Purpose | Round-trip? |
|---------|---------|-------------|
| `cleo export --format todowrite` | Generate TodoWrite JSON for external use | No |
| `cleo sync --inject` | Start sync session | Yes |
| `cleo sync --extract` | End sync session | Yes |

**Export** is for integration with other tools.
**Sync** is for Claude Code session workflows.

---

## Quick Reference

```bash
# Session start
cleo session start
cleo sync --inject              # Outputs JSON for TodoWrite

# Session end
cleo sync --extract state.json  # Merges changes back
cleo session end

# Check sync status
cleo sync --status              # Show active sync session

# Recovery (if session crashes)
cleo sync --clear               # Remove stale state without merging
```

### Exit Codes

| Code | Meaning |
|------|---------|
| `0` | Success |
| `1` | Invalid arguments or missing file |
| `2` | JSON parse error |
| `3` | No tasks to inject |

---

## Visual Data Flow

### Injection Flow

```
┌──────────────────────────────────────────────────────────────────────────┐
│                         INJECTION FLOW                                    │
├──────────────────────────────────────────────────────────────────────────┤
│                                                                          │
│  .cleo/todo.json                                                       │
│  ┌─────────────────────────────────────────┐                            │
│  │ tasks: [                                │                            │
│  │   {id: "T001", title: "Impl auth",      │                            │
│  │    status: "active", priority: "high",  │                            │
│  │    phase: "core", depends: [...]}       │                            │
│  │ ]                                       │                            │
│  │ focus: {currentTask: "T001"}            │                            │
│  └─────────────────────────────────────────┘                            │
│                     │                                                    │
│                     ▼                                                    │
│  ┌─────────────────────────────────────────┐                            │
│  │ inject-todowrite.sh                     │                            │
│  │ 1. Read focus.currentTask               │                            │
│  │ 2. Tiered selection (max 8)             │                            │
│  │ 3. Format: [T###] [!] [phase] title     │                            │
│  │ 4. Generate activeForm                  │                            │
│  │ 5. Map status → TodoWrite status        │                            │
│  │ 6. Save session state                   │                            │
│  └─────────────────────────────────────────┘                            │
│                     │                                                    │
│        ┌────────────┴────────────┐                                      │
│        ▼                         ▼                                      │
│  Session State              TodoWrite JSON                               │
│  (.cleo/sync/)            (stdout)                                    │
│  ┌──────────────┐           ┌──────────────────────────────┐            │
│  │session_id    │           │{"todos": [                   │            │
│  │injected_at   │           │  {"content": "[T001] [!]...  │            │
│  │injectedPhase │           │   "status": "in_progress",   │            │
│  │injected_tasks│           │   "activeForm": "Impl..."}   │            │
│  │task_metadata │           │]}                            │            │
│  │snapshot      │           └──────────────────────────────┘            │
│  └──────────────┘                                                       │
│                                                                          │
└──────────────────────────────────────────────────────────────────────────┘
```

### Extraction Flow

```
┌──────────────────────────────────────────────────────────────────────────┐
│                         EXTRACTION FLOW                                   │
├──────────────────────────────────────────────────────────────────────────┤
│                                                                          │
│  TodoWrite Final State                 Session State                     │
│  (from Claude session)                 (.cleo/sync/)                   │
│  ┌──────────────────────────┐          ┌──────────────┐                 │
│  │{"todos": [               │          │injected_tasks│                 │
│  │  {"content": "[T001]..." │          │task_metadata │                 │
│  │   "status": "completed"} │          └──────────────┘                 │
│  │  {"content": "New task"  │                │                          │
│  │   "status": "pending"}   │                │                          │
│  │]}                        │                │                          │
│  └──────────────────────────┘                │                          │
│                     │                        │                          │
│                     └──────────┬─────────────┘                          │
│                                ▼                                        │
│  ┌─────────────────────────────────────────┐                            │
│  │ extract-todowrite.sh                    │                            │
│  │ 1. Parse [T###] from content            │                            │
│  │ 2. Compare injected vs found IDs        │                            │
│  │ 3. Detect: completed, progressed,       │                            │
│  │    new_tasks, removed                   │                            │
│  │ 4. Apply via task scripts               │                            │
│  │ 5. Delete session state                 │                            │
│  └─────────────────────────────────────────┘                            │
│                     │                                                    │
│                     ▼                                                    │
│  ┌─────────────────────────────────────────┐                            │
│  │ .cleo/todo.json (updated)             │                            │
│  │ - T001: status → done                   │                            │
│  │ - T010: NEW (title: "New task",         │                            │
│  │         labels: ["session-created"],    │                            │
│  │         phase: inherited from focus)    │                            │
│  └─────────────────────────────────────────┘                            │
│                                                                          │
└──────────────────────────────────────────────────────────────────────────┘
```

---

## TL;DR

1. **Inject** embeds task IDs as `[T001]` prefixes in TodoWrite content
2. **Claude works normally** with TodoWrite during the session
3. **Extract** parses those prefixes to identify tasks and sync changes back
4. **New tasks** get created, **completed tasks** get marked done
5. **Everything else** stays safe in cleo's persistent storage

It's like giving Claude a "working copy" of your tasks, then merging the changes when done - similar to how git branches work.

---

## Pending Development (v2)

### Not Yet Implemented

| Feature | Status | Notes |
|---------|--------|-------|
| Full topological sort | PENDING | Proper dependency ordering during injection |
| Blocker chain display `[BLOCKED:T→T→T]` | PENDING | Show full dependency chain, not just `[BLOCKED]` |
| New task confirmation workflow | PLANNED | Ask user before auto-creating (currently auto-creates) |
| Phase completion detection | PLANNED | Detect when all tasks in a phase are done |
| Auto-advance mechanism | PLANNED | Automatically advance to next phase |
| Hook automation | PLANNED | See below |

### About Claude Code Hooks

Claude Code has a hook system (PreToolUse, PostToolUse, UserPromptSubmit, Stop, etc.) that can run scripts at specific lifecycle points.

**Research was done** (Task T227.6, December 2025) but the key finding was:

> **Hooks cannot call TodoWrite directly.**

Hooks can run shell commands and provide prompts to Claude, but they cannot programmatically invoke Claude's internal tools like TodoWrite.

**Designed hybrid architecture** (not built):

```
SessionStart Hook:
  1. Command hook: cleo sync --inject --output /tmp/tasks.json
  2. Prompt hook: "Claude, load tasks from /tmp/tasks.json into TodoWrite"

SessionEnd Hook:
  1. Prompt hook: "Claude, output TodoWrite state to /tmp/state.json"
  2. Command hook: cleo sync --extract /tmp/state.json
```

**No hooks are used.** Sync is triggered by:
- Instructions in CLAUDE.md telling Claude to run the commands
- Or manual user commands

```bash                                                                                                                                                                        
# These must be run explicitly (no automation)
cleo sync --inject
cleo sync --extract
```

**Why not automated yet?**
- **Complexity**: Hybrid hooks require coordinating command + prompt hooks
- **Reliability**: Prompt hooks depend on Claude following additional instructions and so far system has been working
- **v1 Priority**: Manual commands work; automation is a v2 enhancement

---

*This is the TodoWrite sync system in cleo v0.31.0+*
