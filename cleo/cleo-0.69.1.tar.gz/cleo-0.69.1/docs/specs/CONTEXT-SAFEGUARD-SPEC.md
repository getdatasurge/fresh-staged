# Context Safeguard System Specification

**Epic**: T1198 - EPIC: Context Safeguard System (Agent Graceful Shutdown)
**Version**: 0.1.0 (Draft)
**Status**: Design Phase

---

## 1. Overview

### 1.1 Problem Statement

When AI agents (Claude Code sessions) approach their context window limits (~200K tokens), they can be cut off mid-task, leaving:
- Uncommitted code changes
- Incomplete task notes
- No handoff documentation for continuation
- Orphaned CLEO sessions

### 1.2 Solution

A CLEO-integrated context safeguard system that:
1. **Monitors** context window usage in real-time
2. **Alerts** agents at configurable thresholds
3. **Triggers** graceful shutdown procedures
4. **Ensures** proper state persistence for session continuity

### 1.3 Design Principles

- **Non-invasive**: Works with existing Claude Code mechanisms (status line hooks)
- **Agent-cooperative**: Agents voluntarily check and respond (not forceful)
- **Fallback-protected**: PreCompact hook as emergency backstop
- **Session-aware**: Integrates with CLEO session lifecycle

---

## 2. Architecture

### 2.1 Component Diagram

```
┌─────────────────────────────────────────────────────────────────────┐
│                         Claude Code Session                          │
│  ┌─────────────┐                              ┌──────────────────┐  │
│  │   Context   │──── JSON (stdin) ──────────►│  Status Line     │  │
│  │   Window    │      (~300ms)                │  Script          │  │
│  │   State     │                              │  (CLEO-provided) │  │
│  └─────────────┘                              └────────┬─────────┘  │
│                                                        │            │
│  ┌─────────────┐                                       ▼            │
│  │  PreCompact │──── Hook Event ─────────►  .cleo/.context-state   │
│  │    Hook     │      (95% trigger)               .json             │
│  └─────────────┘                                       │            │
└────────────────────────────────────────────────────────┼────────────┘
                                                         │
                    ┌────────────────────────────────────┼───────────┐
                    │                CLEO CLI                        │
                    │                                    ▼           │
                    │  ┌──────────────────────────────────────────┐  │
                    │  │  cleo context [status|check|watch]       │  │
                    │  │  - Reads .context-state.json             │  │
                    │  │  - Returns threshold status              │  │
                    │  │  - Exit codes: 0=ok, 1=warning, 2=crit   │  │
                    │  └──────────────────────────────────────────┘  │
                    │                        │                       │
                    │                        ▼ (if critical)         │
                    │  ┌──────────────────────────────────────────┐  │
                    │  │  cleo safestop                           │  │
                    │  │  1. Update task notes                    │  │
                    │  │  2. Git commit (optional)                │  │
                    │  │  3. Generate handoff doc                 │  │
                    │  │  4. End session                          │  │
                    │  └──────────────────────────────────────────┘  │
                    └────────────────────────────────────────────────┘
```

### 2.2 Data Flow

1. **Claude Code** updates context window state internally
2. **Status line hook** receives JSON every ~300ms
3. **CLEO status line script** parses and writes to `.cleo/.context-state.json`
4. **Agent** periodically runs `cleo context check`
5. **On threshold breach**, agent runs `cleo safestop`
6. **Fallback**: PreCompact hook triggers safestop at 95% if agent didn't

---

## 3. File Schemas

### 3.1 Context State File (`.cleo/.context-state.json`)

```json
{
  "$schema": "https://cleo-dev.com/schemas/v1/context-state.schema.json",
  "version": "1.0.0",
  "timestamp": "2026-01-02T08:15:00Z",
  "staleAfterMs": 5000,
  "contextWindow": {
    "maxTokens": 200000,
    "currentTokens": 156000,
    "percentage": 78,
    "breakdown": {
      "inputTokens": 140000,
      "outputTokens": 12000,
      "cacheCreationTokens": 4000,
      "cacheReadTokens": 0
    }
  },
  "thresholds": {
    "warning": 70,
    "caution": 85,
    "critical": 90,
    "emergency": 95
  },
  "status": "caution",
  "claudeSessionId": "session_abc123",
  "cleoSessionId": "session_20260102_001434_ab3e6d"
}
```

### 3.2 Config Addition (`config.json`)

```json
{
  "contextSafeguard": {
    "enabled": true,
    "thresholds": {
      "warning": 70,
      "caution": 85,
      "critical": 90,
      "emergency": 95
    },
    "autoSafestop": {
      "enabled": true,
      "triggerAt": "critical",
      "commitChanges": true,
      "generateHandoff": true
    },
    "stateFile": ".cleo/.context-state.json",
    "staleness": {
      "warnAfterMs": 5000,
      "errorAfterMs": 30000
    }
  }
}
```

### 3.3 Handoff Document Schema

```json
{
  "$schema": "https://cleo-dev.com/schemas/v1/handoff.schema.json",
  "version": "1.0.0",
  "generatedAt": "2026-01-02T08:20:00Z",
  "reason": "context-limit",
  "contextPercentage": 92,
  "session": {
    "cleoSessionId": "session_20260102_001434_ab3e6d",
    "claudeSessionId": "session_abc123",
    "name": "Context Safeguard Architecture",
    "startedAt": "2026-01-02T08:14:34Z",
    "scope": {
      "type": "epic",
      "rootTaskId": "T1185"
    }
  },
  "focusedTask": {
    "id": "T1199",
    "title": "Define context state file schema",
    "status": "active",
    "progressNote": "Drafted schema, needs review"
  },
  "workInProgress": {
    "description": "Designing context-state.json schema with threshold configuration",
    "filesModified": [
      "docs/specs/CONTEXT-SAFEGUARD-SPEC.md",
      "schemas/context-state.schema.json"
    ],
    "gitStatus": "3 files changed, 245 insertions",
    "uncommittedChanges": true
  },
  "nextSteps": [
    "Review context-state.json schema",
    "Implement status line integration script",
    "Add config.json schema updates"
  ],
  "resumeCommand": "cleo session resume session_20260102_001434_ab3e6d"
}
```

---

## 4. Commands

### 4.1 `cleo context`

```bash
# Show current context state
cleo context status
# Output:
# Context: 78% (156,000 / 200,000 tokens)
# Status: ⚠️  CAUTION (threshold: 85%)
# Updated: 2s ago
# Session: session_20260102_001434_ab3e6d

# Check threshold (for scripting)
cleo context check
# Exit codes:
#   0 = ok (below warning)
#   1 = warning (70-84%)
#   2 = caution (85-89%)
#   3 = critical (90-94%)
#   4 = emergency (95%+)
#   5 = stale data / no data

# Continuous watch mode
cleo context watch [--interval 5] [--webhook URL]

# JSON output
cleo context status --format json
```

### 4.2 `cleo safestop`

```bash
# Full graceful shutdown
cleo safestop --reason "context-limit" --commit --handoff ./handoff.json

# Dry run (show what would happen)
cleo safestop --dry-run

# Minimal (just end session)
cleo safestop --reason "manual"

# Options:
#   --reason <text>     Reason for stopping (required)
#   --commit            Commit pending git changes
#   --handoff <file>    Generate handoff document (- for stdout)
#   --no-session-end    Update notes but don't end session
#   --dry-run           Show actions without executing
```

**Safestop Sequence:**

1. **Validate session**: Check active CLEO session exists
2. **Capture state**:
   - Read focused task
   - Read uncommitted git changes
   - Read session notes
3. **Update task notes**:
   ```bash
   cleo focus note "⚠️ CONTEXT LIMIT (92%): <reason>. Progress: <current work>"
   ```
4. **Git commit** (if `--commit`):
   ```bash
   git add -A
   git commit -m "WIP: <task-title> - safestop (<reason>)"
   ```
5. **Generate handoff** (if `--handoff`):
   - Create structured JSON with continuation context
6. **End session**:
   ```bash
   cleo session end --note "Safestop: <reason> at <percentage>%"
   ```
7. **Output summary**: Display what was saved and how to resume

---

## 5. Status Line Integration

### 5.1 Installation

Users configure Claude Code to use CLEO's status line script:

```json
// ~/.claude/settings.json
{
  "statusLine": {
    "type": "command",
    "command": "~/.cleo/bin/cleo-statusline"
  }
}
```

### 5.2 Script Implementation (`lib/context-monitor.sh`)

```bash
#!/usr/bin/env bash
# CLEO Status Line Integration for Claude Code
# Reads context window JSON from stdin, writes to .context-state.json

set -euo pipefail

CLEO_DIR="${CLEO_PROJECT_DIR:-.cleo}"
STATE_FILE="$CLEO_DIR/.context-state.json"
CONFIG_FILE="$CLEO_DIR/config.json"

# Read JSON from stdin
input=$(cat)

# Extract context window data
CONTEXT_SIZE=$(echo "$input" | jq -r '.context_window.context_window_size // 200000')
CURRENT_USAGE=$(echo "$input" | jq -r '.context_window.current_usage // {}')

if [ "$CURRENT_USAGE" != "{}" ] && [ "$CURRENT_USAGE" != "null" ]; then
    INPUT_TOKENS=$(echo "$CURRENT_USAGE" | jq -r '.input_tokens // 0')
    OUTPUT_TOKENS=$(echo "$CURRENT_USAGE" | jq -r '.output_tokens // 0')
    CACHE_CREATE=$(echo "$CURRENT_USAGE" | jq -r '.cache_creation_input_tokens // 0')
    CACHE_READ=$(echo "$CURRENT_USAGE" | jq -r '.cache_read_input_tokens // 0')

    TOTAL_TOKENS=$((INPUT_TOKENS + OUTPUT_TOKENS + CACHE_CREATE))
    PERCENTAGE=$((TOTAL_TOKENS * 100 / CONTEXT_SIZE))

    # Determine status based on thresholds
    if [ "$PERCENTAGE" -ge 95 ]; then
        STATUS="emergency"
        ICON="🚨"
    elif [ "$PERCENTAGE" -ge 90 ]; then
        STATUS="critical"
        ICON="🔴"
    elif [ "$PERCENTAGE" -ge 85 ]; then
        STATUS="caution"
        ICON="🟠"
    elif [ "$PERCENTAGE" -ge 70 ]; then
        STATUS="warning"
        ICON="🟡"
    else
        STATUS="ok"
        ICON="🟢"
    fi

    # Write state file
    jq -n \
        --arg ts "$(date -u +%Y-%m-%dT%H:%M:%SZ)" \
        --argjson max "$CONTEXT_SIZE" \
        --argjson current "$TOTAL_TOKENS" \
        --argjson pct "$PERCENTAGE" \
        --arg status "$STATUS" \
        --arg claude_session "${CLAUDE_SESSION_ID:-}" \
        --arg cleo_session "$(cat "$CLEO_DIR/.current-session" 2>/dev/null || echo '')" \
        '{
            version: "1.0.0",
            timestamp: $ts,
            staleAfterMs: 5000,
            contextWindow: {
                maxTokens: $max,
                currentTokens: $current,
                percentage: $pct
            },
            status: $status,
            claudeSessionId: $claude_session,
            cleoSessionId: $cleo_session
        }' > "$STATE_FILE"

    # Display status line
    echo "$ICON ${PERCENTAGE}% | ${TOTAL_TOKENS}/${CONTEXT_SIZE}"
else
    echo "📊 --"
fi
```

---

## 6. Agent Protocol

### 6.1 Recommended Agent Behavior

Agents should include context awareness in their operational loop:

```markdown
## Context Awareness Protocol

1. **Periodic Check**: Every 10-15 tool calls, run `cleo context check`
2. **Threshold Response**:
   - **Warning (70%)**: Log awareness, continue work
   - **Caution (85%)**: Start wrapping up current subtask
   - **Critical (90%)**: Complete current operation, then safestop
   - **Emergency (95%)**: Immediate safestop

3. **Safestop Procedure**:
   ```bash
   cleo safestop --reason "context-limit" --commit --handoff -
   ```

4. **Handoff**: Output handoff document content for orchestrator
```

### 6.2 CLAUDE.md Injection

```markdown
### Context Awareness (v0.44.0+)

CLEO monitors Claude Code context window usage. Check periodically:

```bash
cleo context check    # Exit code indicates threshold
cleo context status   # Human-readable status
```

**When approaching limits (85%+):**
1. Wrap up current work
2. Run: `cleo safestop --reason "context-limit" --commit --handoff -`
3. Stop and let orchestrator resume in new session

**Threshold Exit Codes:**
- 0: OK (<70%)
- 1: Warning (70-84%)
- 2: Caution (85-89%)
- 3: Critical (90-94%)
- 4: Emergency (95%+)
```

---

## 7. PreCompact Hook (Emergency Fallback)

### 7.1 Hook Configuration

```json
// ~/.claude/settings.json
{
  "hooks": {
    "PreCompact": [{
      "type": "command",
      "command": "~/.cleo/hooks/precompact-safestop.sh",
      "timeout": 30
    }]
  }
}
```

### 7.2 Hook Implementation

```bash
#!/usr/bin/env bash
# PreCompact Hook - Emergency Safestop Fallback
# Triggers when Claude Code auto-compact fires (95% usage)

CLEO_DIR="${CLEO_PROJECT_DIR:-.cleo}"
SESSION_FILE="$CLEO_DIR/.current-session"

# Check if CLEO session is active
if [ -f "$SESSION_FILE" ]; then
    SESSION_ID=$(cat "$SESSION_FILE")

    # Log the emergency trigger
    echo "[CLEO] PreCompact triggered - initiating emergency safestop" >&2

    # Run safestop with emergency flag
    cleo safestop \
        --reason "precompact-emergency" \
        --commit \
        --handoff "$CLEO_DIR/handoff-emergency-$(date +%s).json" \
        2>&1 | tee -a "$CLEO_DIR/safestop.log"

    # Signal to Claude that safestop was performed
    echo "⚠️ CLEO Emergency Safestop executed. Session ended. Check handoff document."
else
    echo "[CLEO] PreCompact triggered but no active CLEO session" >&2
fi
```

---

## 8. Implementation Plan

### Phase 1: Foundation (T1199, T1200)
- Define context-state.json schema
- Implement status line integration script
- Add config.json schema updates

### Phase 2: Core Commands (T1201, T1202)
- Implement `cleo context` command
- Implement `cleo safestop` command
- Unit tests for both

### Phase 3: Integration (T1203, T1204)
- Document agent protocol
- Implement PreCompact hook
- Integration tests

### Phase 4: Polish
- CLAUDE.md injection updates
- Example workflows
- Performance optimization

---

## 9. Open Questions

1. **Session binding**: Should we require explicit binding of Claude session ID to CLEO session, or auto-detect from environment?

2. **Multi-session**: How does this work with CLEO's multi-session mode where multiple agents might be active?

3. **Orchestrator integration**: Should safestop output a machine-readable signal for orchestrators to detect and handle?

4. **Recovery**: Should there be a `cleo resume --from-handoff <file>` command?

---

## 10. References

- [Claude Code Context Windows](https://platform.claude.com/docs/en/build-with-claude/context-windows)
- [Claude Code Hooks](https://code.claude.com/docs/en/hooks)
- [Claude Code Status Line](https://code.claude.com/docs/en/statusline)
- [CLEO Multi-Session Spec](./MULTI-SESSION-SPEC.md)
- [Context Monitoring Research](../research/claude-context-monitoring.md)
