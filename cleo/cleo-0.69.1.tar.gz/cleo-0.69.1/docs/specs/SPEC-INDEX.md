# Specification Index

> **GENERATED FILE** - This markdown is generated from [`SPEC-INDEX.json`](SPEC-INDEX.json).
> For programmatic access, use the JSON file directly.

**Purpose**: Human-readable view of the specification catalog
**Last Updated**: 2025-12-29
**Total Specifications**: 22 | **Implementation Reports**: 6
**Index Version**: 1.1.0

---

## LLM Agent Usage (Preferred)

```bash
# Query authoritative source for a domain
jq '.authorities["task-ids"]' docs/specs/SPEC-INDEX.json
# → "LLM-TASK-ID-SYSTEM-DESIGN-SPEC.md"

# List all IMMUTABLE specs
jq '.specs[] | select(.status == "IMMUTABLE") | .file' docs/specs/SPEC-INDEX.json

# Get dependencies for a spec
jq '.specs[] | select(.file == "TASK-HIERARCHY-SPEC.md") | .dependsOn' docs/specs/SPEC-INDEX.json

# Find specs by domain
jq '.specs[] | select(.domain == "phase-lifecycle")' docs/specs/SPEC-INDEX.json

# Get implementation progress
jq '.reports[] | {file, progress, notes}' docs/specs/SPEC-INDEX.json
```

### Why JSON?

| Aspect | JSON | Markdown |
|--------|------|----------|
| Parsing | `jq`, native | Regex, heuristics |
| Validation | Schema-enforced | None |
| Queries | Structured (`select`, `map`) | Text search |
| Updates | Programmatic | Manual editing |
| Token efficiency | Compact | Formatting overhead |

---

## Human Navigation

### For Developers
1. Start with **Status** to understand document maturity
2. Check **Synopsis** for quick understanding
3. Follow **Implementation Report** links for current progress

---

## Quick Reference

### Spec Status Legend

| Status | Meaning | Can Change | When to Use |
|--------|---------|------------|-------------|
| **IMMUTABLE** | Locked forever, authoritative reference | NEVER | Permanent design decisions |
| **ACTIVE** | Current design, may evolve carefully | Yes (versioned) | Evolving features |
| **APPROVED** | Endorsed for implementation | Yes (formal amendments) | Stable designs |
| **DRAFT** | Work in progress | Yes (freely) | New designs under review |
| **DEPRECATED** | Historical only, superseded | No | Legacy reference |

### Document Type Legend

| Type | Purpose | Contains |
|------|---------|----------|
| **SPEC** | Requirements and contracts | WHAT system does |
| **IMPLEMENTATION-REPORT** | Progress tracking | Status, checklists, % |
| **GUIDELINES** | Standards and best practices | HOW to write specs |
| **PLAN** | Implementation strategy | Sequencing, tasks |

### Status Distribution

| Status | Count | Documents |
|--------|-------|-----------|
| **IMMUTABLE** | 2 | SPEC-BIBLE-GUIDELINES, LLM-TASK-ID-SYSTEM-DESIGN-SPEC |
| **ACTIVE** | 5 | LLM-AGENT-FIRST, CONFIG-SYSTEM, FILE-LOCKING, PHASE-SYSTEM, TODOWRITE-SYNC |
| **APPROVED** | 1 | HIERARCHY-ENHANCEMENT |
| **DRAFT** | 2 | FIND-COMMAND, RELEASE-VERSION-MANAGEMENT |
| **PLANNING** | 1 | LLM-AGENT-FIRST-FINALIZATION-PLAN |
| **IMPLEMENTED** | 3 | PHASE-DELETE, PHASE-RENAME, PHASE-ROLLBACK |

---

## All Specifications

### Core System Specifications

| Document | Version | Status | Last Updated | Synopsis |
|----------|---------|--------|--------------|----------|
| [**SPEC-BIBLE-GUIDELINES.md**](SPEC-BIBLE-GUIDELINES.md) | 1.0.0 | **IMMUTABLE** | 2025-12-17 | Authoritative standards for writing specifications. Defines SPEC vs IMPLEMENTATION-REPORT separation, RFC 2119 usage, status lifecycle. |
| [**LLM-TASK-ID-SYSTEM-DESIGN-SPEC.md**](LLM-TASK-ID-SYSTEM-DESIGN-SPEC.md) | 1.0.0 FINAL | **IMMUTABLE** | 2025-01-17 | Task ID system design (T001 format). Flat sequential IDs with parentId for hierarchy. Six guarantees: unique, immutable, stable, sequential, referenceable, recoverable. |
| [**LLM-AGENT-FIRST-SPEC.md**](LLM-AGENT-FIRST-SPEC.md) | 3.0 | **ACTIVE** | 2025-12-18 | CLI design standard for LLM agents. JSON output by default, TTY auto-detection, 32 commands, standardized exit/error codes, universal flags. |
| [**PHASE-SYSTEM-SPEC.md**](PHASE-SYSTEM-SPEC.md) | v2.2.0+ | **ACTIVE** | 2025-12-17 | Dual-level phase model: project lifecycle phases vs task categorization. Defines phase transitions, history, validation rules. |
| [**CONFIG-SYSTEM-SPEC.md**](CONFIG-SYSTEM-SPEC.md) | 1.0.0 | **ACTIVE** | 2025-12-19 | Configuration system with global (~/.cleo/config.json) and project (.cleo/config.json) configs. Priority resolution, environment variables. |
| [**FILE-LOCKING-SPEC.md**](FILE-LOCKING-SPEC.md) | 1.0.0 | **ACTIVE** | 2025-12-19 | File locking & concurrency safety. Exclusive locks via flock, 30s timeout, atomic write operations, error recovery. |

### Feature Specifications

| Document | Version | Status | Last Updated | Synopsis |
|----------|---------|--------|--------------|----------|
| [**TASK-HIERARCHY-SPEC.md**](TASK-HIERARCHY-SPEC.md) | 2.0.0 | **APPROVED** | 2025-12-29 | Epic → Task → Subtask taxonomy with max depth 3, unlimited siblings by default. Flat ID + parentId design. LLM-Agent-First. |
| [**TODOWRITE-SYNC-SPEC.md**](TODOWRITE-SYNC-SPEC.md) | 1.0.0 | **ACTIVE** | 2025-12-18 | Bidirectional sync between cleo (durable) and Claude Code TodoWrite (ephemeral). Lossy by design with ID preservation via [T###] prefix. |
| [**FIND-COMMAND-SPEC.md**](FIND-COMMAND-SPEC.md) | 1.0 | **DRAFT** | 2025-12-18 | Fuzzy task search command. Context reduction 355KB→1KB (99.7%). ID prefix matching, match scoring, minimal output. |
| [**RELEASE-VERSION-MANAGEMENT-SPEC.md**](RELEASE-VERSION-MANAGEMENT-SPEC.md) | 2.0.0 | **DRAFT** | 2025-12-18 | Release version tracking with 4-state lifecycle (planning→development→released/cancelled). VERSION file integration, git tags. |

### Pipeline & Orchestration Specifications

| Document | Version | Status | Last Updated | Synopsis |
|----------|---------|--------|--------------|----------|
| [**CLEO-SYSTEM-ARCHITECTURE-SPEC.md**](CLEO-SYSTEM-ARCHITECTURE-SPEC.md) | 1.0.0 | **DRAFT** | 2025-12-29 | High-level architecture connecting all CLEO subsystems. Complete lifecycle from idea to release. Exit code allocation. |
| [**RCSD-PIPELINE-SPEC.md**](RCSD-PIPELINE-SPEC.md) | 2.0.0 | **DRAFT** | 2025-12-29 | Research-Consensus-Spec-Decompose pipeline. 4-stage workflow transforming research into atomic tasks. Exit codes 30-39. |
| [**CONSENSUS-FRAMEWORK-SPEC.md**](CONSENSUS-FRAMEWORK-SPEC.md) | 2.0.0 | **ACTIVE** | 2025-12-23 | 7-agent consensus framework (5 workers + synthesis + orchestrator). Adversarial validation with HITL gates. |
| [**TASK-DECOMPOSITION-SPEC.md**](TASK-DECOMPOSITION-SPEC.md) | 1.0.0 | **ACTIVE** | 2025-12-23 | HTN-style task decomposition with atomicity validation. Wave computation from dependency DAG. |
| [**IMPLEMENTATION-ORCHESTRATION-SPEC.md**](IMPLEMENTATION-ORCHESTRATION-SPEC.md) | 1.1.0 | **DRAFT** | 2025-12-29 | 7-agent implementation workflow (Planner→Coder→Testing→QA→Cleanup→Security→Docs). Verification gates. Exit codes 40-49. |
| [**RELEASE-MANAGEMENT-SPEC.md**](RELEASE-MANAGEMENT-SPEC.md) | 1.0.0 | **DRAFT** | 2025-12-29 | Release lifecycle (planned→staging→released). Changelog generation, roadmap, git tags. Exit codes 50-59. |
| [**ISSUE-LIFECYCLE-SPEC.md**](ISSUE-LIFECYCLE-SPEC.md) | 1.0.0 | **DRAFT** | 2025-12-29 | Bug/issue tracking via origin field. Triage, severity, verification protocol. Exit codes 60-69. |

### Session & Lifecycle Specifications

| Document | Version | Status | Last Updated | Synopsis |
|----------|---------|--------|--------------|----------|
| [**MULTI-SESSION-SPEC.md**](MULTI-SESSION-SPEC.md) | 1.0.0 | **ACTIVE** | 2025-12-27 | Concurrent agent sessions with scope isolation. Epic-bound session architecture. Exit codes 20-29. |
| [**EPIC-SESSION-SPEC.md**](EPIC-SESSION-SPEC.md) | 1.0.0 | **ACTIVE** | 2025-12-27 | Epic-scoped session binding. Session-task relationship management. |
| [**PROJECT-LIFECYCLE-SPEC.md**](PROJECT-LIFECYCLE-SPEC.md) | 1.0.0 | **DRAFT** | 2025-12-22 | Greenfield/brownfield/grayfield patterns. Two-dimensional work model (Epics × Phases). |

### Planning Documents

| Document | Version | Status | Last Updated | Synopsis |
|----------|---------|--------|--------------|----------|
| [**LLM-AGENT-FIRST-FINALIZATION-PLAN.md**](LLM-AGENT-FIRST-FINALIZATION-PLAN.md) | - | **PLANNING** | 2025-12-18 | Addresses 47 findings from 5 adversarial agents. 4 phases (P0-P3) with 28 tasks. Performance (689 jq calls→~50), test coverage (0%→80%). |

### Phase Implementation Guides

| Document | Version | Status | Last Updated | Synopsis |
|----------|---------|--------|--------------|----------|
| [**PHASE-DELETE-IMPLEMENTATION.md**](PHASE-DELETE-IMPLEMENTATION.md) | - | **IMPLEMENTED** | v0.16.0+ | `phase delete` command with orphan prevention, force flag, task reassignment. |
| [**PHASE-RENAME-IMPLEMENTATION.md**](PHASE-RENAME-IMPLEMENTATION.md) | - | **IMPLEMENTED** | v0.16.0+ | Atomic phase rename with task reference updates and rollback safety. |
| [**PHASE-ROLLBACK-IMPLEMENTATION.md**](PHASE-ROLLBACK-IMPLEMENTATION.md) | - | **IMPLEMENTED** | v0.14.0 | Rollback detection with --rollback flag, interactive confirmation, JSON mode. |

---

## Implementation Reports

| Specification | Implementation Report | Progress | Notes |
|---------------|----------------------|----------|-------|
| LLM-AGENT-FIRST-SPEC | [LLM-AGENT-FIRST-IMPLEMENTATION-REPORT.md](LLM-AGENT-FIRST-IMPLEMENTATION-REPORT.md) | **100%** | All 32 commands have complete `_meta` envelopes |
| TODOWRITE-SYNC-SPEC | [TODOWRITE-SYNC-IMPLEMENTATION-REPORT.md](TODOWRITE-SYNC-IMPLEMENTATION-REPORT.md) | 85% | 16/18 core features complete, v1 stable |
| FILE-LOCKING-SPEC | [FILE-LOCKING-IMPLEMENTATION-REPORT.md](FILE-LOCKING-IMPLEMENTATION-REPORT.md) | ~70% | Core done, script integration partial |
| CONFIG-SYSTEM-SPEC | [CONFIG-SYSTEM-IMPLEMENTATION-REPORT.md](CONFIG-SYSTEM-IMPLEMENTATION-REPORT.md) | ~60% | 8/14 components complete (T382 epic) |
| LLM-TASK-ID-SYSTEM-DESIGN-SPEC | [LLM-TASK-ID-SYSTEM-DESIGN-IMPLEMENTATION-REPORT.md](LLM-TASK-ID-SYSTEM-DESIGN-IMPLEMENTATION-REPORT.md) | Varies | ID system works, hierarchy pending |
| RELEASE-VERSION-MANAGEMENT-SPEC | [RELEASE-VERSION-MANAGEMENT-IMPLEMENTATION-REPORT.md](RELEASE-VERSION-MANAGEMENT-IMPLEMENTATION-REPORT.md) | 0% | Research complete, v0.20.0 target |

---

## Domain Authority Map

> **What is this?** Declares which specification is the AUTHORITATIVE source for each domain.
> When specs conflict, defer to the authoritative source.

| Domain | Authoritative Spec | Defers To |
|--------|-------------------|-----------|
| **System Architecture** | [CLEO-SYSTEM-ARCHITECTURE-SPEC.md](CLEO-SYSTEM-ARCHITECTURE-SPEC.md) | All domain specs for details |
| **Task IDs** | [LLM-TASK-ID-SYSTEM-DESIGN-SPEC.md](LLM-TASK-ID-SYSTEM-DESIGN-SPEC.md) | - |
| **Specification Writing** | [SPEC-BIBLE-GUIDELINES.md](SPEC-BIBLE-GUIDELINES.md) | - |
| **LLM-First Design** | [LLM-AGENT-FIRST-SPEC.md](LLM-AGENT-FIRST-SPEC.md) | SPEC-BIBLE-GUIDELINES for spec structure |
| **Phase Lifecycle** | [PHASE-SYSTEM-SPEC.md](PHASE-SYSTEM-SPEC.md) | LLM-TASK-ID-SYSTEM-DESIGN-SPEC for ID handling |
| **Task Hierarchy** | [TASK-HIERARCHY-SPEC.md](TASK-HIERARCHY-SPEC.md) | LLM-TASK-ID-SYSTEM-DESIGN-SPEC for ID contract |
| **TodoWrite Sync** | [TODOWRITE-SYNC-SPEC.md](TODOWRITE-SYNC-SPEC.md) | LLM-TASK-ID-SYSTEM-DESIGN-SPEC for IDs, PHASE-SYSTEM-SPEC for phases |
| **Configuration** | [CONFIG-SYSTEM-SPEC.md](CONFIG-SYSTEM-SPEC.md) | - |
| **File Operations** | [FILE-LOCKING-SPEC.md](FILE-LOCKING-SPEC.md) | - |
| **Versioning** | [RELEASE-VERSION-MANAGEMENT-SPEC.md](RELEASE-VERSION-MANAGEMENT-SPEC.md) | - |
| **Search** | [FIND-COMMAND-SPEC.md](FIND-COMMAND-SPEC.md) | LLM-TASK-ID-SYSTEM-DESIGN-SPEC for ID validation |
| **RCSD Pipeline** | [RCSD-PIPELINE-SPEC.md](RCSD-PIPELINE-SPEC.md) | CONSENSUS-FRAMEWORK-SPEC, TASK-DECOMPOSITION-SPEC |
| **Multi-Agent Consensus** | [CONSENSUS-FRAMEWORK-SPEC.md](CONSENSUS-FRAMEWORK-SPEC.md) | - |
| **Task Decomposition** | [TASK-DECOMPOSITION-SPEC.md](TASK-DECOMPOSITION-SPEC.md) | PHASE-SYSTEM-SPEC for phases |
| **Implementation Orchestration** | [IMPLEMENTATION-ORCHESTRATION-SPEC.md](IMPLEMENTATION-ORCHESTRATION-SPEC.md) | MULTI-SESSION-SPEC for sessions |
| **Release Management** | [RELEASE-MANAGEMENT-SPEC.md](RELEASE-MANAGEMENT-SPEC.md) | IMPLEMENTATION-ORCHESTRATION-SPEC |
| **Issue Lifecycle** | [ISSUE-LIFECYCLE-SPEC.md](ISSUE-LIFECYCLE-SPEC.md) | RELEASE-MANAGEMENT-SPEC |
| **Multi-Session** | [MULTI-SESSION-SPEC.md](MULTI-SESSION-SPEC.md) | - |
| **Project Lifecycle** | [PROJECT-LIFECYCLE-SPEC.md](PROJECT-LIFECYCLE-SPEC.md) | PHASE-SYSTEM-SPEC |

---

## Specification Dependencies

### Dependency Graph

```
SPEC-BIBLE-GUIDELINES.md (Meta-level authority)
    │
    ├─► All specifications follow these guidelines
    │
    └─► LLM-TASK-ID-SYSTEM-DESIGN-SPEC.md (ID authority - IMMUTABLE)
            │
            ├─► PHASE-SYSTEM-SPEC.md
            │       ├─► PHASE-DELETE-IMPLEMENTATION.md
            │       ├─► PHASE-RENAME-IMPLEMENTATION.md
            │       └─► PHASE-ROLLBACK-IMPLEMENTATION.md
            │
            ├─► TASK-HIERARCHY-SPEC.md
            │       └─► Depends on: flat ID + parentId design
            │
            ├─► TODOWRITE-SYNC-SPEC.md
            │       └─► Depends on: ID format, PHASE-SYSTEM-SPEC
            │
            └─► FIND-COMMAND-SPEC.md
                    └─► Depends on: ID validation patterns

LLM-AGENT-FIRST-SPEC.md (Design philosophy)
    │
    └─► Influences: all command implementations

FILE-LOCKING-SPEC.md (Infrastructure)
    │
    └─► Depended on by: all write operations

CONFIG-SYSTEM-SPEC.md (Infrastructure)
    │
    └─► Provides config for: all features
```

### Dependency Table

| Specification | Depends On | Depended On By |
|---------------|------------|----------------|
| SPEC-BIBLE-GUIDELINES | - | All specs (meta) |
| LLM-TASK-ID-SYSTEM-DESIGN-SPEC | - | PHASE-SYSTEM, HIERARCHY, TODOWRITE-SYNC, FIND-COMMAND |
| PHASE-SYSTEM-SPEC | LLM-TASK-ID-SYSTEM-DESIGN-SPEC | TODOWRITE-SYNC, phase implementation guides |
| TASK-HIERARCHY-SPEC | LLM-TASK-ID-SYSTEM-DESIGN-SPEC | - |
| TODOWRITE-SYNC-SPEC | LLM-TASK-ID-SYSTEM-DESIGN-SPEC, PHASE-SYSTEM | - |
| CONFIG-SYSTEM-SPEC | - | All features (config provider) |
| FILE-LOCKING-SPEC | - | All write operations |
| LLM-AGENT-FIRST-SPEC | SPEC-BIBLE-GUIDELINES | All command implementations |
| FIND-COMMAND-SPEC | LLM-TASK-ID-SYSTEM-DESIGN-SPEC | - |
| RELEASE-VERSION-MANAGEMENT-SPEC | - | All deliverables |

---

## Specifications by Category

### Architecture & Design Philosophy
- [CLEO-SYSTEM-ARCHITECTURE-SPEC.md](CLEO-SYSTEM-ARCHITECTURE-SPEC.md) - High-level system architecture
- [SPEC-BIBLE-GUIDELINES.md](SPEC-BIBLE-GUIDELINES.md) - Specification writing standards
- [LLM-AGENT-FIRST-SPEC.md](LLM-AGENT-FIRST-SPEC.md) - Agent-optimized design principles
- [PROJECT-LIFECYCLE-SPEC.md](PROJECT-LIFECYCLE-SPEC.md) - Greenfield/brownfield patterns

### Core Systems
- [LLM-TASK-ID-SYSTEM-DESIGN-SPEC.md](LLM-TASK-ID-SYSTEM-DESIGN-SPEC.md) - Task identification
- [FILE-LOCKING-SPEC.md](FILE-LOCKING-SPEC.md) - Concurrency and atomicity
- [CONFIG-SYSTEM-SPEC.md](CONFIG-SYSTEM-SPEC.md) - Configuration management

### Task Management
- [TASK-HIERARCHY-SPEC.md](TASK-HIERARCHY-SPEC.md) - Epic/Task/Subtask structure
- [PHASE-SYSTEM-SPEC.md](PHASE-SYSTEM-SPEC.md) - Phase lifecycle
- [FIND-COMMAND-SPEC.md](FIND-COMMAND-SPEC.md) - Task search
- [TASK-DECOMPOSITION-SPEC.md](TASK-DECOMPOSITION-SPEC.md) - Task breakdown algorithms

### Pipeline & Orchestration
- [RCSD-PIPELINE-SPEC.md](RCSD-PIPELINE-SPEC.md) - Research to task decomposition
- [CONSENSUS-FRAMEWORK-SPEC.md](CONSENSUS-FRAMEWORK-SPEC.md) - Multi-agent validation
- [IMPLEMENTATION-ORCHESTRATION-SPEC.md](IMPLEMENTATION-ORCHESTRATION-SPEC.md) - Implementation workflow

### Session Management
- [MULTI-SESSION-SPEC.md](MULTI-SESSION-SPEC.md) - Concurrent agent sessions
- [EPIC-SESSION-SPEC.md](EPIC-SESSION-SPEC.md) - Epic-bound sessions

### Release & Issue Management
- [RELEASE-MANAGEMENT-SPEC.md](RELEASE-MANAGEMENT-SPEC.md) - Release lifecycle
- [ISSUE-LIFECYCLE-SPEC.md](ISSUE-LIFECYCLE-SPEC.md) - Bug/issue tracking
- [RELEASE-VERSION-MANAGEMENT-SPEC.md](RELEASE-VERSION-MANAGEMENT-SPEC.md) - Version management

### Integration
- [TODOWRITE-SYNC-SPEC.md](TODOWRITE-SYNC-SPEC.md) - Claude Code integration

---

## Specifications by Status

### IMMUTABLE (Locked Forever)
- [LLM-TASK-ID-SYSTEM-DESIGN-SPEC.md](LLM-TASK-ID-SYSTEM-DESIGN-SPEC.md) - v1.0.0 FINAL
- [SPEC-BIBLE-GUIDELINES.md](SPEC-BIBLE-GUIDELINES.md) - v1.0.0

### ACTIVE (Current, May Evolve)
- [LLM-AGENT-FIRST-SPEC.md](LLM-AGENT-FIRST-SPEC.md) - v3.0
- [PHASE-SYSTEM-SPEC.md](PHASE-SYSTEM-SPEC.md) - v2.2.0+
- [CONFIG-SYSTEM-SPEC.md](CONFIG-SYSTEM-SPEC.md) - v1.0.0
- [FILE-LOCKING-SPEC.md](FILE-LOCKING-SPEC.md) - v1.0.0
- [TODOWRITE-SYNC-SPEC.md](TODOWRITE-SYNC-SPEC.md) - v1.0.0
- [CONSENSUS-FRAMEWORK-SPEC.md](CONSENSUS-FRAMEWORK-SPEC.md) - v2.0.0
- [TASK-DECOMPOSITION-SPEC.md](TASK-DECOMPOSITION-SPEC.md) - v1.0.0
- [MULTI-SESSION-SPEC.md](MULTI-SESSION-SPEC.md) - v1.0.0
- [EPIC-SESSION-SPEC.md](EPIC-SESSION-SPEC.md) - v1.0.0

### APPROVED (Endorsed, Formal Amendments)
- [TASK-HIERARCHY-SPEC.md](TASK-HIERARCHY-SPEC.md) - v2.0.0

### DRAFT (Work in Progress)
- [CLEO-SYSTEM-ARCHITECTURE-SPEC.md](CLEO-SYSTEM-ARCHITECTURE-SPEC.md) - v1.0.0
- [RCSD-PIPELINE-SPEC.md](RCSD-PIPELINE-SPEC.md) - v2.0.0
- [IMPLEMENTATION-ORCHESTRATION-SPEC.md](IMPLEMENTATION-ORCHESTRATION-SPEC.md) - v1.1.0
- [RELEASE-MANAGEMENT-SPEC.md](RELEASE-MANAGEMENT-SPEC.md) - v1.0.0
- [ISSUE-LIFECYCLE-SPEC.md](ISSUE-LIFECYCLE-SPEC.md) - v1.0.0
- [PROJECT-LIFECYCLE-SPEC.md](PROJECT-LIFECYCLE-SPEC.md) - v1.0.0
- [FIND-COMMAND-SPEC.md](FIND-COMMAND-SPEC.md) - v1.0
- [RELEASE-VERSION-MANAGEMENT-SPEC.md](RELEASE-VERSION-MANAGEMENT-SPEC.md) - v2.0.0

---

## Recent Changes Log

> **Maintenance**: Add entries when specs are created, updated, or status changes.
> Keep last 20 entries.

| Date | Specification | Change | Version | Description |
|------|--------------|--------|---------|-------------|
| 2025-12-29 | CLEO-SYSTEM-ARCHITECTURE-SPEC | Created | 1.0.0 | High-level system architecture |
| 2025-12-29 | IMPLEMENTATION-ORCHESTRATION-SPEC | Updated | 1.1.0 | Added Epic lifecycle integration |
| 2025-12-29 | RELEASE-MANAGEMENT-SPEC | Created | 1.0.0 | Release lifecycle, changelog, roadmap |
| 2025-12-29 | ISSUE-LIFECYCLE-SPEC | Created | 1.0.0 | Bug/issue tracking via origin field |
| 2025-12-29 | SCHEMA-CHANGES-SUMMARY | Created | 1.0.0 | Consolidated schema changes reference |
| 2025-12-29 | SPEC-INDEX.md | Updated | 1.1.0 | Added pipeline & orchestration specs |
| 2025-12-29 | TASK-HIERARCHY-SPEC | Updated | 2.0.0 | Schema v2.4.0 |
| 2025-12-27 | MULTI-SESSION-SPEC | Updated | 1.0.0 | Epic-bound session architecture |
| 2025-12-23 | RCSD-PIPELINE-SPEC | Updated | 2.0.0 | Python Agent SDK implementation |
| 2025-12-23 | CONSENSUS-FRAMEWORK-SPEC | Updated | 2.0.0 | 7-agent architecture |
| 2025-12-22 | PROJECT-LIFECYCLE-SPEC | Created | 1.0.0 | Greenfield/brownfield patterns |
| 2025-12-19 | SPEC-INDEX.md | Created | 1.0.0 | Initial specification index |
| 2025-12-19 | CONFIG-SYSTEM-SPEC | Updated | 1.0.0 | Status updated |
| 2025-12-19 | FILE-LOCKING-SPEC | Updated | 1.0.0 | Status updated |
| 2025-12-18 | LLM-AGENT-FIRST-SPEC | Updated | 3.0 | Compliance scoring rubric |
| 2025-12-18 | TODOWRITE-SYNC-SPEC | Updated | 1.0.0 | v1 stable release |
| 2025-12-18 | FIND-COMMAND-SPEC | Created | 1.0 | New search command spec |
| 2025-12-18 | RELEASE-VERSION-MANAGEMENT-SPEC | Updated | 2.0.0 | Research complete |
| 2025-12-17 | SPEC-BIBLE-GUIDELINES | Finalized | 1.0.0 | Set to IMMUTABLE |
| 2025-12-17 | PHASE-SYSTEM-SPEC | Updated | v2.2.0+ | Phase lifecycle commands |

---

## How to Add a New Specification

### Process

1. **Create the specification**
   - Use template from [SPEC-BIBLE-GUIDELINES.md](SPEC-BIBLE-GUIDELINES.md)
   - Follow naming: `[DOMAIN]-SPEC.md` or `[DOMAIN]-[FEATURE]-SPEC.md`
   - Set initial status to **DRAFT**

2. **Create implementation report (optional)**
   - Use template from SPEC-BIBLE-GUIDELINES Part 8
   - Naming: `[SPEC-NAME]-IMPLEMENTATION-REPORT.md`

3. **Update this index**
   - Add entry to appropriate "All Specifications" table
   - Add to "Domain Authority Map" if authoritative
   - Add to "Specification Dependencies" if dependencies exist
   - Add to "Recent Changes Log"
   - Add to appropriate "By Category" section
   - Add to "By Status" section

### Checklist

- Specification file created following SPEC-BIBLE-GUIDELINES
- Implementation report created (if tracking needed)
- Added to "All Specifications" table with synopsis
- Domain authority declared (if authoritative)
- Dependencies documented
- Recent changes log entry added
- Categorized by domain and status
- Cross-referenced in main INDEX.md

---

## Critical Documents for Development

### Must-Read for Any Changes

1. **SPEC-BIBLE-GUIDELINES.md** - How to write/update specs
2. **LLM-AGENT-FIRST-SPEC.md** - All CLI output requirements
3. **LLM-TASK-ID-SYSTEM-DESIGN-SPEC.md** - ID system rules (NEVER change)

### Implementation References

- **LLM-AGENT-FIRST-IMPLEMENTATION-REPORT.md** - Current compliance status
- **CONFIG-SYSTEM-IMPLEMENTATION-REPORT.md** - Config work tracking
- **FILE-LOCKING-IMPLEMENTATION-REPORT.md** - Locking work tracking

---

## Related Documentation

| Document | Purpose |
|----------|---------|
| [../INDEX.md](../INDEX.md) | Main documentation index |
| [../architecture/ARCHITECTURE.md](../architecture/ARCHITECTURE.md) | System architecture |
| [../QUICK-REFERENCE.md](../QUICK-REFERENCE.md) | Developer reference |

---

*Last validated: 2025-12-29*
