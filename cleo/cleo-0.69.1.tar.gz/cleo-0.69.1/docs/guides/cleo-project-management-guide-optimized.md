# CLEO Project Management Guide (Optimized)

**Goal**: Build and manage epics, tasks, and subtasks with clear deps, phases, and ordering.
**Output**: Actionable CLI steps + minimal examples for LLM agents.
**Limits**: **MUST** use CLI only. **MUST** check exit codes. **MUST NOT** edit task JSON directly.
**Data**: Use `ct` alias (or `cleo`). Use `ct analyze --parent <epic-id>` for waves.
**Evaluation**: Deps valid, waves computed, positions consistent, sessions closed.
**Next**: If confidence < 80%, ask for scope, deps, or phase clarification.

---

## 1) Core Model

### 1.1 Hierarchy
- **Epic**: root-level strategic initiative.
- **Task**: primary work unit under an epic.
- **Subtask**: atomic operation under a task.
- **MUST** keep max depth = 3 (epic -> task -> subtask).

### 1.2 Phases (Task vs Project)
- **Task phase**: lifecycle category on each task (setup, core, testing, polish, maintenance).
- **Project phase**: current lifecycle stage for the project.
- **MUST** treat them as distinct.

### 1.3 Dependencies
- Deps define execution order, not hierarchy.
- **MUST** add deps only when ordering is provable.

### 1.4 Waves (Computed)
- Wave 0: no active deps (ready now).
- Wave N: deepest dep is in Wave N-1.
- **MUST** treat waves as computed, not stored.

### 1.5 Positional Ordering (Display)
- Position is sibling order within a parent scope (root is its own scope).
- **MUST** keep positions continuous and unique per parent.
- **SHOULD** use position to express preferred reading/build order.
- **MUST** use deps to enforce actual execution order.

---

## 2) Decomposition and Atomicity

### 2.1 Atomicity (6-point test)
A task is atomic only if all are true:
1) Single file scope (<=3 tightly-coupled files)
2) Single cognitive concern
3) Clear acceptance criteria (testable)
4) No context switching mid-task
5) No hidden sub-decisions
6) Programmatic validation possible

### 2.2 Size Rules (Scope, Not Time)
- `small`: **MUST** be atomic
- `medium`: **SHOULD** be atomic; review if unclear
- `large`: **MUST** decompose into medium/small

### 2.3 Evidence-Based Deps
Only add deps that can be proven by logic, data flow, or validation order.
**MUST NOT** add deps for preference or convenience.

---

## 3) Phases and Lifecycle

### 3.1 Phase Mapping (Lifecycle -> Task Phase)
- Discovery/Planning/Design -> setup (some design may extend into core)
- Build -> core
- Test -> testing
- Release -> polish
- Operate/Improve -> maintenance

### 3.2 Project Phase Control
```bash
ct phase show
ct phase list
ct phase start <phase>
ct phase advance
```

Rules:
- Only one project phase can be active.
- **MUST** complete all tasks in a phase before completing that phase unless forced.
- **MUST** use `--rollback` for backward moves.

---

## 4) Task Creation Rules

### 4.1 Create Epic -> Task -> Subtask
```bash
ct add "EPIC: Auth System" --type epic --size large --description "End-to-end auth"
ct add "Implement login endpoint" --parent T001 --phase core --size medium
ct add "Validate email format" --parent T002 --size small
```

### 4.2 Required Fields
- Title (action-oriented)
- Description (distinct from title)
- Phase (task lifecycle category)
- Size (scope-based)

### 4.3 Type Inference
- No parent -> task
- Parent is epic -> task
- Parent is task -> subtask

---

## 5) Dependencies and Waves

### 5.1 Add or Update Deps
```bash
ct update T010 --depends T002,T003
```

### 5.2 Wave View (Epic Scope)
```bash
ct analyze --parent T001
```

Interpretation:
- `inventory.ready[]` = ready tasks
- `inventory.blocked[]` = blocked tasks
- `executionPlan.waves[]` = parallel groups

---

## 6) Positional Ordering

### 6.1 Set or Change Position
```bash
ct add "New Task" --parent T001 --position 2
ct reorder T005 --position 1
ct reorder T005 --before T002
ct reorder T005 --after T003
ct swap T001 T003
```

### 6.2 View Ordered Tasks
```bash
ct list --sort position
ct list --tree --parent T001
```

Rules:
- **MUST** keep positions continuous per parent.
- **SHOULD** reorder within siblings instead of faking order with deps.

---

## 7) Session and Focus Protocol

### 7.1 Start -> Work -> Close
```bash
ct session status
ct session start --name "Work" --scope epic:<ID>
ct focus set <task-id>
ct update <task-id> --notes "Progress note"
ct complete <task-id>
ct archive
ct session end
```

### 7.2 Discovery Discipline
- **MUST** use `ct find "keywords"` for discovery.
- **SHOULD** use filtered lists: `ct list --status pending --priority high`.
- **MAY** use `ct list` only when full inventory is required.

### 7.3 Data Integrity
- **MUST** use `ct exists <id>` before referencing IDs in scripts.
- **MUST** check exit codes and JSON `success` after each command.
- **MUST NOT** edit task JSON directly.

---

## 8) Structured Output Rules

- **MUST** use JSON output for automation (`--json` or piped output).
- **MUST** use JSON Schema with strict mode when a tool supports it:
```json
{"type":"json_schema","json_schema":{"strict":true,"additionalProperties":false}}
```

---

## 9) Execution Checklist

Before work:
- **MUST** set or resume session
- **MUST** set focus to one task
- **SHOULD** pick Wave 0 tasks first

During work:
- **MUST** update notes for decisions/blockers
- **SHOULD** keep tasks atomic

After work:
- **MUST** complete task when done
- **MUST** close session when done

