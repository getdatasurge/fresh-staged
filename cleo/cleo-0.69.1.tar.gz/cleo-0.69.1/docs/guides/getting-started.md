# CLEO Getting Started Guide

A comprehensive guide to setting up CLEO task management for AI coding agents.

## What is CLEO?

CLEO (Command Line Entity Orchestrator) is a task management system designed for AI coding agents and solo developers. It provides:

- **Anti-hallucination validation** - Every operation is validated before execution
- **Context persistence** - State maintained across sessions with immutable audit trails
- **Structured output** - JSON by default for agent consumption
- **Atomic operations** - All writes use temp file → validate → backup → rename pattern

## Prerequisites

Before installing, ensure you have:

1. **Bash 4.0 or higher**
   ```bash
   bash --version
   # Should output: GNU bash, version 4.0 or higher
   ```

2. **jq (JSON processor)**
   ```bash
   jq --version
   # Should output: jq-1.5 or higher
   ```

   **Installation if missing:**
   - Ubuntu/Debian: `sudo apt-get install jq`
   - macOS: `brew install jq`
   - RHEL/CentOS: `sudo yum install jq`

## Fresh Installation

### 1. Clone and Install

```bash
git clone https://github.com/kryptobaseddev/cleo.git
cd cleo
./install.sh
```

This installs to `~/.cleo/` and creates symlinks in `~/.local/bin/` for immediate access.

### 2. Initialize Your Project

```bash
cd /path/to/your/project
cleo init
```

Creates `.cleo/` directory with:
- `todo.json` - Active tasks
- `todo-archive.json` - Completed tasks
- `config.json` - Configuration
- `todo-log.json` - Change history

Additionally, `cleo init` automatically injects CLEO instructions into CLAUDE.md, AGENTS.md, and GEMINI.md using `<!-- CLEO:START -->` and `<!-- CLEO:END -->` markers.

### 3. Verify Installation

```bash
cleo version
cleo validate
```

## Migration from claude-todo

If you have existing claude-todo installations:

### Check Migration Status

```bash
cleo claude-migrate --check
```

### Migrate Global Installation

```bash
cleo claude-migrate --global
# Moves ~/.cleo/ → ~/.cleo/
```

### Migrate Project Data

```bash
cleo claude-migrate --project
# Moves .claude/ → .cleo/ (preserves all data)
```

### Migrate Everything

```bash
cleo claude-migrate --all
# Runs both --global and --project
```

## Your First Task

### Create a Task

```bash
# Simple task
cleo add "Fix login bug"

# Task with details
cleo add "Implement authentication" \
  --priority high \
  --labels backend,security \
  --description "Add JWT-based authentication"
```

### List Tasks

```bash
# View all tasks
cleo list

# High-priority tasks only
cleo list --priority high

# Compact view
cleo list --compact
```

### Complete a Task

```bash
# Mark task complete
cleo complete T001

# View statistics
cleo stats
```

## Essential Commands

### Task Management

```bash
cleo add "Task title"              # Create task
cleo list                          # View tasks
cleo complete <id>                 # Mark done
cleo update <id> --notes "..."     # Add notes
```

### Focus Management

```bash
cleo focus set <id>                # Set active task (one at a time)
cleo focus show                    # Show current focus
cleo focus clear                   # Clear focus
```

### Session Protocol

#### Morning: Session Start

```bash
cleo session start
cleo list --status pending
cleo focus set <task-id>
```

#### During Work

```bash
cleo add "Discovered task" --priority medium
cleo update <id> --notes "Progress update"
cleo complete <id>
```

#### Evening: Session End

```bash
cleo archive
cleo session end
cleo stats --period 1
```

## Command Aliases

CLEO provides shell aliases for faster workflows:

```bash
# Built-in CLI aliases
cleo ls              # Same as: list
cleo done T001       # Same as: complete T001
cleo new "Task"      # Same as: add "Task"
cleo edit T001       # Same as: update T001
cleo check           # Same as: validate

# Shell aliases (if installed)
ct              # cleo
ct-add          # cleo add
ct-list         # cleo list
ct-done         # cleo complete
ct-focus        # cleo focus
```

## Output Formats

```bash
# Human-readable (default)
cleo list

# JSON for scripting
cleo list --format json

# CSV export (via export command)
cleo export --format csv > tasks.csv

# Markdown checklist
cleo list --format markdown
```

## Configuration

Edit `.cleo/config.json`:

```json
{
  "archive": {
    "daysUntilArchive": 7,
    "preserveRecentCount": 3
  },
  "validation": {
    "maxActiveTasks": 1,
    "requireDescription": false
  },
  "defaults": {
    "priority": "medium",
    "phase": "core"
  }
}
```

## Tips for Success

1. **One Active Task**: Set focus to maintain clarity
   ```bash
   cleo focus set T002
   ```

2. **Use Labels**: Organize with labels
   ```bash
   cleo add "Fix bug" --labels bug,backend,urgent
   ```

3. **Regular Archiving**: Keep active list clean
   ```bash
   cleo archive --dry-run   # Preview
   cleo archive              # Execute
   ```

4. **Track Progress**: Add notes for context
   ```bash
   cleo update T001 --notes "Implemented JWT validation"
   ```

5. **Disable Colors When Needed**: Follow NO_COLOR standard
   ```bash
   NO_COLOR=1 cleo list
   ```

## Common Issues

### Command Not Found

```bash
# Check symlink
ls -l ~/.local/bin/cleo

# If missing, verify PATH
echo $PATH | grep ".local/bin"

# Reload shell if needed
source ~/.bashrc  # or ~/.zshrc
```

### Validation Errors

```bash
# Check file integrity
cleo validate

# Attempt automatic fix
cleo validate --fix

# Restore from backup if needed
cleo restore .cleo/.backups/todo.json.1
```

### jq Not Installed

```bash
# Ubuntu/Debian
sudo apt-get install jq

# macOS
brew install jq

# Verify
jq --version
```

## Next Steps

- **Full Command Reference**: `~/.cleo/docs/TODO_Task_Management.md`
- **Detailed Usage**: See [usage.md](../usage.md) for complete command reference
- **Configuration Guide**: See [configuration.md](../reference/configuration.md) for all settings
- **Architecture**: See [ARCHITECTURE.md](../architecture/ARCHITECTURE.md) for system design
- **Troubleshooting**: See [troubleshooting.md](../reference/troubleshooting.md) for common issues

## Support

- **Documentation**: `~/.cleo/docs/`
- **Command Help**: `cleo <command> --help`
- **Validation**: `cleo validate --fix`
